#ifndef IA32_CPU_JIT_H__
#define IA32_CPU_JIT_H__

UINT64 exec_jit();

#endif
